==========
 MGSEdit:
==========

 Author: Shendo
 Version: 0.2
 Updated: 2021-04-26 (YYYY-MM-DD)

===============
 Requirements:
===============

 MemcardRex 1.9 or higher.

===============
 About MGSEdit:
===============

 MGSEdit is a save editor for Metal Gear Solid.

 Do not forget to backup your save before editing it.

====================
 Licence Agreement:
====================

 "MGSEdit" software is released as a freeware. It must not be used for any commercial purposes.
 "MGSEdit" may not be modified or distributed in any other way than originally packaged.

 Disclaimer
------------
 This software is provided "as is" without any guarantees or warranty. Usage of this software is at the user's own risk.
 The Author, Shendo won't be held responsible if any harm is caused by using this software.

 If you disagree with any part of this Licence Agreement DO NOT use "MGSEdit".

============
 ChangeLog:
============

 Version 0.2:
--------------------
 * Bumped up .NET requirements to 4.5.

 Version 0.1:
--------------------
* Initial release.

==========
 Contact:
==========

 To report a bug or make a suggestion please mail to:
 shendo[dot]extreme[dot]99[at]gmail[dot]com

 Copyright � Shendo 2012 - 2021.