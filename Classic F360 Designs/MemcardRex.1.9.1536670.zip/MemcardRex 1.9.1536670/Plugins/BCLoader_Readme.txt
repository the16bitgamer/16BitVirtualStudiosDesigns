===========
 BCLoader:
===========

 Author: Shendo
 Version: 0.3
 Updated: 2021-04-26

===============
 Requirements:
===============

 MemcardRex 1.9 or higher.

=================
 About BCLoader:
=================

 BCLoader is a loader plugin for FF7 save editor called Black Chocobo.
 For more information check the application's readme or about dialog.
 To select Black Chocobo's location press Config button in the plugin manager.

 Do not forget to backup your save before editing it.

====================
 Licence Agreement:
====================

 BCLoader software is released as a freeware. It must not be used for any commercial purposes.
 BCLoader may not be modified or distributed in any other way than originally packaged.

 Disclaimer
------------
 This software is provided "as is" without any guarantees or warranty. Usage of this software is at the user's own risk.
 The Author, Shendo won't be held responsible if any harm is caused by using this software.

 If you disagree with any part of this Licence Agreement DO NOT use BCLoader.

============
 ChangeLog:
============

 Version 0.3:
--------------------
 * Bumped up .NET requirements to 4.5.

 Version 0.2:
--------------------
* Changed output name of temp file to adjust to Black Chocobo's new detection of FF7 saves.
* Changed about dialog to make it prettier.

 Version 0.1:
--------------------
* Initial release.

==========
 Contact:
==========

 To report a bug or make a suggestion please mail to:
 shendo[dot]extreme[dot]99[at]gmail[dot]com

 Copyright � Shendo 2012 - 2021.